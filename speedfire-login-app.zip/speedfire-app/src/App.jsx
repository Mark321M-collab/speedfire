import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://nlnwxksciooiqngcgmct.supabase.com";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sbnd4a3NjaW9vaXFuZ2NnbWN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkyMDIwMjEsImV4cCI6MjA2NDc3ODAyMX0.96VvftuFQ8GQl1kQTTj5T_xkgfvz6a_e8F5dM4GV59U";
const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default function App() {
  const [email, setEmail] = useState("");
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const adminEmail = "missianimark4@gmail.com";

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setUser(data.session.user);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user?.email === adminEmail) {
      supabase.from("users").select("id, email, created_at").then(({ data }) => {
        if (data) setUsers(data);
      });
    }
  }, [user]);

  const handleLogin = async () => {
    if (!email) return alert("Please enter a valid email.");
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) alert(error.message);
    else alert("Check your inbox for the login link.");
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="p-8 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Speedfire App</h1>

      {!user ? (
        <div>
          <input
            className="border p-2 w-full mb-2"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={handleLogin}>
            Send Magic Link
          </button>
        </div>
      ) : (
        <div>
          <p className="mb-2">Logged in as: {user.email}</p>
          <button className="bg-red-500 text-white px-4 py-2 rounded" onClick={handleLogout}>
            Logout
          </button>

          {user.email === adminEmail && (
            <div className="mt-6">
              <h2 className="text-xl font-semibold mb-2">All Users</h2>
              <ul>
                {users.map((u) => (
                  <li key={u.id} className="border-b py-1">
                    {u.email} – {new Date(u.created_at).toLocaleString()}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}